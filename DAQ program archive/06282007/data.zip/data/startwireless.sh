wpa_supplicant -c/etc/wpa_supplicant/wpa_supplicant.conf -iwlan0 -B
dhclient -H daqsbc070606 wlan0
