/sbin/insmod daqdrv.ko
/sbin/rmmod daqdrv.ko
tail -n 20 /var/log/messages
