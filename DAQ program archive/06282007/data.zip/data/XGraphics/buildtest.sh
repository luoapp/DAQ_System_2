gcc -Wall -DXGRAPHICSTEST xgraphics.c -o xgraphics -lX11 -lm
