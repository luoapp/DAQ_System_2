there=`pwd`
here=`dirname $0`

cd ${here}

# start the daq card driver

./daqdrv/daqdriver/daqdrvstart.sh


# start your data acquisition program here



